Contributor's Guidelines
========================

.. toctree::
    :maxdepth: 2
    :numbered:

    coding_style
    design
    versioning
    documentation
    patches
    cheatsheet
